package dummydomain.yetanothercallblocker.event;

public class SecondaryDbUpdatingEvent {}

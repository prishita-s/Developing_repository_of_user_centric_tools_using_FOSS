package dummydomain.yetanothercallblocker.event;

public class MainDbDownloadingEvent {}

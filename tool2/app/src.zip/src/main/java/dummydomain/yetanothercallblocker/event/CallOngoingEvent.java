package dummydomain.yetanothercallblocker.event;

public class CallOngoingEvent extends CallEvent {}

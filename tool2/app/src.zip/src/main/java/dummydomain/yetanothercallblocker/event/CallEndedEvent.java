package dummydomain.yetanothercallblocker.event;

public class CallEndedEvent extends CallEvent {}

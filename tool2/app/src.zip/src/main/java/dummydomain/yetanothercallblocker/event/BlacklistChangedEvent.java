package dummydomain.yetanothercallblocker.event;

public class BlacklistChangedEvent {}

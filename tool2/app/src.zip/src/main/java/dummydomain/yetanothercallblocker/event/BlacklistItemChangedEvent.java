package dummydomain.yetanothercallblocker.event;

public class BlacklistItemChangedEvent extends BlacklistChangedEvent {}

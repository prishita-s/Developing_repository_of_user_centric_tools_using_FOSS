package dummydomain.yetanothercallblocker.event;

public class CallEvent {}

package dummydomain.yetanothercallblocker.data;

public interface SiaConstants {

    String SIA_PROPERTIES = "sia_preferences";
    String SIA_PATH_PREFIX = "sia/";
    String SIA_SECONDARY_PATH_PREFIX = "sia-secondary/";

}
